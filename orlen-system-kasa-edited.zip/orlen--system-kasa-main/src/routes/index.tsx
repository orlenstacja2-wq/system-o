import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { LogOut, MapPin, RefreshCw, ShieldCheck } from 'lucide-react'

import { Clock } from '@/components/clock'
import { Dispensers } from '@/components/dispensers'
import { OrlenLogo } from '@/components/orlen-logo'
import { PrintHost } from '@/components/receipt'
import { Register } from '@/components/register'
import { PriceList, SalesHistory } from '@/components/station-panels'
import { useStation } from '@/hooks/use-station'
import {
  STATION,
  withPrices,
  type PriceMap,
} from '@/lib/station'
import type { Fueling, PanelData } from '@/lib/types'
import { getBootstrap, login, logout, setupStation } from '@/server/auth.functions'
import { publishCustomerDisplay } from '@/server/customer-display.functions'
import {
  cancelFueling,
  endShift,
  getPanelData,
  startShift,
} from '@/server/station.functions'

export const Route = createFileRoute('/')({
  component: Home,
})

type Bootstrap = {
  needsSetup: boolean
  setupCodeRequired: boolean
  me: { id: number; login: string; name: string; role: string } | null
}

function Home() {
  const [bootstrap, setBootstrap] = useState<Bootstrap | null>(null)
  const [panel, setPanel] = useState<PanelData | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [loginName, setLoginName] = useState('')
  const [pin, setPin] = useState('')
  const [setupName, setSetupName] = useState('')
  const [setupLogin, setSetupLogin] = useState('')
  const [setupPin, setSetupPin] = useState('')
  const [setupCode, setSetupCode] = useState('')
  const [registerId, setRegisterId] = useState('')
  const [openingNote, setOpeningNote] = useState('')
  const selectPumpRef = useRef<((pump: number) => void) | null>(null)
  const [activePump, setActivePump] = useState<number | null>(null)
  const [printJob, setPrintJob] = useState<{ sale: Fueling; nonce: number } | null>(null)

  const fuels = useMemo(
    () =>
      withPrices(
        Object.fromEntries((panel?.prices ?? []).map((p) => [p.fuelId, p.price])) as PriceMap,
      ),
    [panel?.prices],
  )
  // Keep the existing dispenser UI, but never start simulated customers.
  const station = useStation(false, fuels)

  const refreshBootstrap = useCallback(async () => {
    const result = await getBootstrap()
    setBootstrap(result as Bootstrap)
    return result as Bootstrap
  }, [])

  const refreshPanel = useCallback(async () => {
    const data = await getPanelData()
    setPanel(data as PanelData)
    setRegisterId((current) => current || String((data as PanelData).registers[0]?.id ?? ''))
    return data as PanelData
  }, [])

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const result = (await getBootstrap()) as Bootstrap
        if (!alive) return
        setBootstrap(result)
        if (result.me) {
          try {
            const data = (await getPanelData()) as PanelData
            if (alive) {
              setPanel(data)
              setRegisterId(String(data.shift?.register.id ?? data.registers[0]?.id ?? ''))
            }
          } catch (err) {
            if (alive) setError(errorMessage(err))
          }
        }
      } catch (err) {
        if (alive) setError(errorMessage(err))
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => {
      alive = false
    }
  }, [])

  const handleLogin = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setBusy(true)
    setError('')
    try {
      await login({ data: { login: loginName, pin } })
      const current = await refreshBootstrap()
      if (current.me) await refreshPanel()
      setPin('')
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const handleSetup = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setBusy(true)
    setError('')
    try {
      await setupStation({
        data: {
          name: setupName,
          login: setupLogin,
          pin: setupPin,
          setupCode: setupCode || undefined,
        },
      })
      const current = await refreshBootstrap()
      if (current.me) await refreshPanel()
      setSetupPin('')
      setSetupCode('')
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const handleLogout = async () => {
    setBusy(true)
    setError('')
    try {
      await publishCustomerDisplay({ data: { active: false, pump: null, fuel: null, liters: 0, pricePerLiter: 0, amount: 0, payment: null, vitay: null, promotion: null, stage: 'idle' } }).catch(() => undefined)
      await logout()
      setPanel(null)
      setPin('')
      await refreshBootstrap()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const handleStartShift = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!registerId) {
      setError('Najpierw wybierz kasę.')
      return
    }
    setBusy(true)
    setError('')
    try {
      await startShift({
        data: {
          registerId: Number(registerId),
          note: openingNote || undefined,
        },
      })
      setOpeningNote('')
      await refreshPanel()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const handleEndShift = async () => {
    const response = window.prompt('Uwagi do zakończenia zmiany (opcjonalnie):')
    if (response === null) return
    const note = response
    setBusy(true)
    setError('')
    try {
      await endShift({ data: { note } })
      await refreshPanel()
      await publishCustomerDisplay({ data: { active: false, pump: null, fuel: null, liters: 0, pricePerLiter: 0, amount: 0, payment: null, vitay: null, promotion: null, stage: 'idle' } }).catch(() => undefined)
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const handleCancelSale = async (sale: Fueling) => {
    const reason = window.prompt(`Podaj powód anulowania ${sale.docNumber}:`)
    if (!reason || reason.trim().length < 3) return
    setBusy(true)
    try {
      await cancelFueling({ data: { id: sale.id, reason: reason.trim() } })
      await refreshPanel()
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const print = useCallback((sale: Fueling) => {
    setPrintJob({ sale, nonce: Date.now() })
  }, [])
  const clearPrint = useCallback(() => setPrintJob(null), [])

  // F1–F5 select dispensers from anywhere on the cashier screen.
  useEffect(() => {
    if (!panel?.shift) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.repeat || event.ctrlKey || event.altKey || event.metaKey) return
      const target = event.target as HTMLElement | null
      if (target?.matches('input, textarea, select, [contenteditable="true"]')) return
      const match = /^F([1-5])$/.exec(event.key)
      if (!match) return
      event.preventDefault()
      selectPumpRef.current?.(Number(match[1]))
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [panel?.shift])

  const onRecorded = useCallback(
    (sale: Fueling, pumpTxId: string | null) => {
      setPanel((current) =>
        current
          ? { ...current, fuelings: [sale, ...current.fuelings.filter((item) => item.id !== sale.id)] }
          : current,
      )
      if (pumpTxId) station.release(sale.pump, pumpTxId)
      void refreshPanel().catch((err) => setError(errorMessage(err)))
    },
    [refreshPanel, station.release],
  )

  if (loading) {
    return (
      <main className="grid min-h-screen place-items-center p-6">
        <div className="flex items-center gap-3 text-muted-foreground">
          <RefreshCw className="size-5 animate-spin" />
          Ładowanie systemu stacji…
        </div>
      </main>
    )
  }

  if (error && !bootstrap && !panel) {
    return (
      <main className="grid min-h-screen place-items-center bg-background p-6">
        <section className="w-full max-w-xl rounded-2xl border bg-card p-6 shadow-sm">
          <OrlenLogo className="mb-5 text-3xl" />
          <h1 className="text-2xl font-bold">Nie można uruchomić systemu</h1>
          <p className="mt-2 text-muted-foreground">{error}</p>
          <p className="mt-3 text-sm text-muted-foreground">
            Sprawdź konfigurację Netlify Database i wdrożenie. To nie jest problem samego kodu PIN.
          </p>
          <button className="mt-5 rounded-lg bg-primary px-4 py-2 font-semibold text-primary-foreground" onClick={() => window.location.reload()}>
            Spróbuj ponownie
          </button>
        </section>
      </main>
    )
  }

  if (error && bootstrap?.me && !panel) {
    return (
      <main className="grid min-h-screen place-items-center bg-background p-6">
        <section className="w-full max-w-xl rounded-2xl border bg-card p-6 shadow-sm">
          <OrlenLogo className="mb-5 text-3xl" />
          <h1 className="text-2xl font-bold">Nie można załadować panelu</h1>
          <p className="mt-2 text-muted-foreground">{error}</p>
          <button
            className="mt-5 rounded-lg bg-primary px-4 py-2 font-semibold text-primary-foreground"
            onClick={() => window.location.reload()}
          >
            Spróbuj ponownie
          </button>
        </section>
      </main>
    )
  }

  if (bootstrap?.needsSetup) {
    return (
      <main className="grid min-h-screen place-items-center bg-background p-6">
        <form onSubmit={handleSetup} className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-sm">
          <OrlenLogo className="mb-6 text-3xl" />
          <div className="mb-6 flex items-center gap-3">
            <ShieldCheck className="size-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">Pierwsza konfiguracja</h1>
              <p className="text-sm text-muted-foreground">Utwórz konto administratora stacji.</p>
            </div>
          </div>
          <Field label="Imię i nazwisko" value={setupName} onChange={setSetupName} required />
          <Field label="Login administratora" value={setupLogin} onChange={setSetupLogin} required />
          <Field label="PIN (4–8 cyfr)" value={setupPin} onChange={setSetupPin} required type="password" pattern="[0-9]{4,8}" />
          {bootstrap.setupCodeRequired && <Field label="Kod konfiguracji" value={setupCode} onChange={setSetupCode} required type="password" />}
          <ErrorMessage message={error} />
          <button disabled={busy} className="mt-5 w-full rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground disabled:opacity-50">
            {busy ? 'Konfigurowanie…' : 'Utwórz administratora'}
          </button>
        </form>
      </main>
    )
  }

  if (!panel) {
    return (
      <main className="grid min-h-screen place-items-center bg-background p-6">
        <form onSubmit={handleLogin} className="w-full max-w-md rounded-2xl border bg-card p-6 shadow-sm">
          <OrlenLogo className="mb-6 text-4xl" />
          <p className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-primary">System obsługi stacji paliw</p>
          <h1 className="text-2xl font-bold">Logowanie pracownika</h1>
          <p className="mb-6 mt-1 text-sm text-muted-foreground">Wpisz login i PIN przypisany do Twojego konta.</p>
          <Field label="Login" value={loginName} onChange={setLoginName} required autoComplete="username" />
          <Field label="PIN" value={pin} onChange={setPin} required type="password" inputMode="numeric" autoComplete="current-password" />
          <ErrorMessage message={error} />
          <button disabled={busy} className="mt-5 w-full rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground disabled:opacity-50">
            {busy ? 'Logowanie…' : 'Zaloguj'}
          </button>
        </form>
      </main>
    )
  }

  if (!panel.shift) {
    const availableRegisters = panel.registers.filter((reg) => reg.active && !reg.occupiedBy)
    return (
      <main className="grid min-h-screen place-items-center bg-background p-6">
        <section className="w-full max-w-xl rounded-2xl border bg-card p-6 shadow-sm">
          <header className="mb-6 flex items-center justify-between gap-4">
            <div>
              <OrlenLogo className="text-3xl" />
              <p className="mt-2 text-sm text-muted-foreground">Zalogowano: {panel.me.name} · {panel.me.role}</p>
            </div>
            <button onClick={handleLogout} className="rounded-lg border px-3 py-2 text-sm font-semibold" disabled={busy}>Wyloguj</button>
          </header>
          <h1 className="text-2xl font-bold">Rozpocznij zmianę</h1>
          <p className="mb-5 mt-1 text-sm text-muted-foreground">Wybierz kasę przed rozpoczęciem rejestrowania tankowań.</p>
          <form onSubmit={handleStartShift} className="space-y-4">
            <label className="block text-sm font-medium">
              Kasa
              <select className="mt-1 w-full rounded-lg border bg-background px-3 py-3" value={registerId} onChange={(e) => setRegisterId(e.target.value)} required>
                <option value="">Wybierz kasę…</option>
                {panel.registers.filter((r) => r.active).map((reg) => (
                  <option key={reg.id} value={reg.id} disabled={Boolean(reg.occupiedBy && reg.id !== panel.shift?.register.id)}>
                    {reg.code} — {reg.name}{reg.occupiedBy ? ` (zajęta: ${reg.occupiedBy})` : ''}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm font-medium">
              Uwagi przy otwarciu (opcjonalnie)
              <textarea className="mt-1 w-full rounded-lg border bg-background px-3 py-2" rows={2} value={openingNote} onChange={(e) => setOpeningNote(e.target.value)} maxLength={500} />
            </label>
            <ErrorMessage message={error} />
            <button disabled={busy || availableRegisters.length === 0} className="w-full rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground disabled:opacity-50">
              {busy ? 'Otwieranie zmiany…' : 'Wybierz kasę i rozpocznij zmianę'}
            </button>
            {availableRegisters.length === 0 && <p className="text-sm text-destructive">Brak wolnych kas. Poproś kierownika o sprawdzenie statusu kas.</p>}
          </form>
        </section>
      </main>
    )
  }

  const updatedAt = panel.prices.map((p) => p.updatedAt).filter((value): value is string => Boolean(value)).sort().at(-1) ?? null

  return (
    <>
      <div className="flex min-h-screen flex-col lg:h-screen">
        <header className="flex items-center justify-between gap-4 border-b-4 border-primary bg-card px-4 py-3 sm:px-6">
          <div className="flex items-center gap-4">
            <OrlenLogo className="text-3xl" />
            <div className="hidden border-l pl-4 md:block">
              <h1 className="font-display text-lg font-bold leading-tight">System obsługi stacji paliw</h1>
              <p className="flex items-center gap-1 text-sm text-muted-foreground">
                <MapPin className="size-3.5 text-primary" />
                {STATION.street}, {STATION.city} · Kasa {panel.shift.register.code}
              </p>
              <p className="text-xs text-muted-foreground">{panel.me.name} · {panel.me.role}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Clock className="text-right" />
            <button type="button" onClick={handleEndShift} disabled={busy} className="rounded-lg border px-3 py-2 text-sm font-semibold hover:border-primary disabled:opacity-50">Zakończ zmianę</button>
            <button type="button" onClick={handleLogout} disabled={busy} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-semibold text-muted-foreground hover:border-primary disabled:opacity-50">
              <LogOut className="size-4" /><span className="hidden sm:inline">Wyloguj</span>
            </button>
          </div>
        </header>
        {error && <div role="alert" className="bg-destructive/10 px-4 py-2 text-center text-sm text-destructive">{error}</div>}
        <main className="grid min-h-0 flex-1 gap-4 p-4 sm:px-6 lg:grid-cols-[minmax(0,1fr)_28rem]">
          <div className="flex min-h-0 flex-col gap-4 lg:overflow-auto">
            <Dispensers
              pumps={station.pumps}
              activePump={activePump}
              fuels={fuels}
              onSelect={(pump) => selectPumpRef.current?.(pump)}
            />
            <div className="grid min-h-0 flex-1 gap-4 xl:grid-cols-[20rem_minmax(0,1fr)]">
              <PriceList fuels={fuels} updatedAt={updatedAt} />
              <SalesHistory sales={panel.fuelings} onPrint={print} onCancel={handleCancelSale} />
            </div>
          </div>
          <Register
            pumps={station.pumps}
            fuels={fuels}
            promotions={panel.promotions}
            shiftId={panel.shift.id}
            registerCode={panel.shift.register.code}
            selectPumpRef={selectPumpRef}
            onActivePumpChange={setActivePump}
            lock={station.lock}
            onRecorded={onRecorded}
            onPrint={print}
          />
        </main>
      </div>
      <PrintHost job={printJob} onDone={clearPrint} />
    </>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  required = false,
  ...props
}: {
  label: string
  value: string
  onChange: (value: string) => void
  type?: string
  required?: boolean
  autoComplete?: string
  inputMode?: 'text' | 'numeric' | 'decimal' | 'tel' | 'search' | 'email' | 'url' | 'none'
  pattern?: string
}) {
  const id = label.toLowerCase().replace(/[^a-z0-9]+/g, '-')
  return (
    <label htmlFor={id} className="mb-4 block text-sm font-medium">
      {label}
      <input
        id={id}
        className="mt-1 w-full rounded-lg border bg-background px-3 py-3"
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        required={required}
        {...props}
      />
    </label>
  )
}

function ErrorMessage({ message }: { message: string }) {
  return message ? <p role="alert" className="mt-3 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{message}</p> : null
}

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Wystąpił nieoczekiwany błąd.'
}
