import { useEffect, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'

import { OrlenLogo } from '@/components/orlen-logo'
import { formatLiters, formatMoney, formatUnitPrice } from '@/lib/station'
import { getCustomerDisplay } from '@/server/customer-display.functions'
import type { CustomerDisplayData } from '@/server/customer-display.functions'

export const Route = createFileRoute('/customer')({ component: CustomerDisplay })

function CustomerDisplay() {
  const [display, setDisplay] = useState<CustomerDisplayData | null>(null)
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    let alive = true
    const refresh = async () => {
      try {
        const result = await getCustomerDisplay()
        if (alive) {
          setDisplay(result)
          setConnected(true)
        }
      } catch {
        if (alive) setConnected(false)
      }
    }
    void refresh()
    const timer = window.setInterval(() => void refresh(), 1500)
    return () => { alive = false; window.clearInterval(timer) }
  }, [])

  const active = display?.active
  return (
    <main className="min-h-screen bg-[#f4f5f6] p-4 text-[#202124] sm:p-8">
      <div className="mx-auto flex min-h-[calc(100vh-2rem)] max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-xl sm:min-h-[calc(100vh-4rem)]">
        <header className="flex items-center justify-between border-b-8 border-primary px-6 py-5 sm:px-10">
          <OrlenLogo className="h-14 sm:h-20" width={260} />
          <span className="text-right text-xs font-semibold uppercase tracking-widest text-gray-500 sm:text-sm">Wyświetlacz klienta</span>
        </header>

        {active ? (
          <section className="grid flex-1 gap-6 p-6 sm:grid-cols-[1.1fr_0.9fr] sm:p-10">
            <div className="flex flex-col justify-center">
              <p className="text-lg font-semibold text-gray-500 sm:text-2xl">Dystrybutor {display?.pump ?? '—'}</p>
              <h1 className="mt-2 text-3xl font-extrabold sm:text-5xl">{display?.fuel ?? 'Wybór paliwa'}</h1>
              <div className="mt-8 rounded-2xl bg-gray-50 p-5 sm:p-7">
                <p className="text-sm font-semibold uppercase tracking-wider text-gray-500 sm:text-base">Cena za litr</p>
                <p className="mt-1 text-3xl font-bold sm:text-4xl">{display?.pricePerLiter ? `${formatUnitPrice(display.pricePerLiter)} zł/l` : '—'}</p>
                <div className="mt-5 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-wider text-gray-500 sm:text-base">Ilość</p>
                    <p className="mt-1 text-2xl font-bold sm:text-3xl">{formatLiters(display?.liters ?? 0)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold uppercase tracking-wider text-gray-500 sm:text-base">Do zapłaty</p>
                    <p className="mt-1 text-4xl font-extrabold text-primary sm:text-6xl">{formatMoney(display?.amount ?? 0)} zł</p>
                  </div>
                </div>
              </div>
              <div className="mt-5 flex flex-wrap gap-3 text-sm sm:text-base">
                <span className="rounded-full bg-gray-100 px-4 py-2">Płatność: <strong>{display?.payment === 'gotowka' ? 'Gotówka' : display?.payment === 'karta' ? 'Karta' : 'do wyboru'}</strong></span>
                {display?.vitay && <span className="rounded-full bg-red-50 px-4 py-2">ORLEN VITAY: <strong>{display.vitay}</strong></span>}
              </div>
            </div>
            <aside className="flex flex-col justify-center gap-4">
              <div className="rounded-3xl bg-primary p-6 text-white sm:p-8">
                <p className="text-sm font-bold uppercase tracking-[0.2em] text-white/80">Promocje ORLEN</p>
                <h2 className="mt-3 text-2xl font-extrabold sm:text-3xl">{display?.promotion ?? 'Sprawdź aktualne promocje'}</h2>
                <p className="mt-3 text-sm text-white/90 sm:text-base">Zapytaj obsługę o dostępne oferty i korzyści dla klientów ORLEN VITAY.</p>
              </div>
              <div className="rounded-3xl border border-gray-200 p-6 sm:p-8">
                <p className="text-lg font-bold sm:text-xl">Dziękujemy za wizytę!</p>
                <p className="mt-2 text-sm text-gray-500 sm:text-base">Prosimy sprawdzić kwotę przed zakończeniem płatności.</p>
              </div>
            </aside>
          </section>
        ) : (
          <section className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center sm:px-10">
            <div className="rounded-3xl bg-gray-50 p-8 sm:p-12">
              <h1 className="text-3xl font-extrabold sm:text-5xl">Witamy na stacji ORLEN</h1>
              <p className="mx-auto mt-4 max-w-xl text-lg text-gray-600 sm:text-2xl">Zapraszamy do tankowania. Podsumowanie transakcji pojawi się tutaj automatycznie.</p>
            </div>
            <div className="mt-8 w-full max-w-2xl rounded-3xl bg-primary p-6 text-left text-white sm:p-8">
              <p className="text-sm font-bold uppercase tracking-[0.2em] text-white/80">Promocje ORLEN</p>
              <h2 className="mt-3 text-2xl font-extrabold sm:text-3xl">Odkryj korzyści ORLEN VITAY</h2>
              <p className="mt-2 text-white/90 sm:text-lg">Zapytaj obsługę o aktualne oferty i promocje.</p>
            </div>
          </section>
        )}
        <footer className="flex items-center justify-between border-t px-6 py-3 text-xs text-gray-400 sm:px-10 sm:text-sm">
          <span>{connected ? 'Połączono z kasą' : 'Oczekiwanie na połączenie'}</span>
          <span>ORLEN</span>
        </footer>
      </div>
    </main>
  )
}
