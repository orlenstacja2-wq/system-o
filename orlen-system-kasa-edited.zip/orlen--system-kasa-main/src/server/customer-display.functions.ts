import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { stationSettings } from '../../db/schema.js'
import { requireRole, safe } from './auth.server'

const CUSTOMER_DISPLAY_KEY = 'customer_display_state'

const displaySchema = z.object({
  active: z.boolean(),
  pump: z.number().int().min(1).max(5).nullable(),
  fuel: z.string().max(80).nullable(),
  liters: z.number().min(0).max(999),
  pricePerLiter: z.number().min(0).max(50),
  amount: z.number().min(0).max(50000),
  payment: z.enum(['gotowka', 'karta']).nullable(),
  vitay: z.string().max(40).nullable(),
  promotion: z.string().max(100).nullable(),
  stage: z.string().max(40),
})

export type CustomerDisplayData = z.infer<typeof displaySchema> & {
  updatedAt: string
}

/** Cashier-only write; only masked customer details are published to the public display. */
export const publishCustomerDisplay = createServerFn({ method: 'POST' })
  .validator(displaySchema)
  .handler(({ data }) =>
    safe(async () => {
      const me = await requireRole()
      const values = { value: data, updatedBy: me.id, updatedAt: new Date() }
      await db
        .insert(stationSettings)
        .values({ key: CUSTOMER_DISPLAY_KEY, ...values })
        .onConflictDoUpdate({ target: stationSettings.key, set: values })
      return { ok: true }
    }),
  )

/** Public read endpoint for the customer-facing tablet screen. No account data is returned. */
export const getCustomerDisplay = createServerFn({ method: 'GET' }).handler(() =>
  safe(async (): Promise<CustomerDisplayData | null> => {
    const [row] = await db
      .select({ value: stationSettings.value, updatedAt: stationSettings.updatedAt })
      .from(stationSettings)
      .where(eq(stationSettings.key, CUSTOMER_DISPLAY_KEY))
    if (!row) return null
    const parsed = displaySchema.safeParse(row.value)
    if (!parsed.success) return null
    return { ...parsed.data, updatedAt: row.updatedAt.toISOString() }
  }),
)
